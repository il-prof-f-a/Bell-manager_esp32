#ifndef API_HANDLERS_H
#define API_HANDLERS_H

#include <WebServer.h>
#include <ArduinoJson.h>
#include "config.h"
#include "bell_types.h"
#include "gpio_control.h"
#include "time_sync.h"
#include "storage.h"
#include "schedule_engine.h"
#include "wifi_manager.h"

// ============================================
// Handler API REST v2.0
// ============================================

// Riferimenti esterni
extern WebServer server;
extern Bell bells[];
extern uint8_t bellCount;
extern Settings settings;
extern SystemStatus systemStatus;

// === Helper Functions ===

uint8_t findFreeId() {
    for (uint8_t id = 1; id <= 255; id++) {
        bool found = false;
        for (uint8_t i = 0; i < bellCount; i++) {
            if (bells[i].id == id) { found = true; break; }
        }
        if (!found) return id;
    }
    return 0;
}

int findBellById(uint8_t id) {
    for (uint8_t i = 0; i < bellCount; i++) {
        if (bells[i].id == id) return i;
    }
    return -1;
}

void sendError(int code, const char* message) {
    JsonDocument doc;
    doc["error"] = true;
    doc["message"] = message;
    String response;
    serializeJson(doc, response);
    server.send(code, "application/json", response);
}

void sendSuccess(const char* message) {
    JsonDocument doc;
    doc["success"] = true;
    doc["message"] = message;
    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
}

void addCorsHeaders() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.sendHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
}

void handleOptions() {
    addCorsHeaders();
    server.send(204);
}

// === BELLS API ===

void handleGetBells() {
    addCorsHeaders();
    JsonDocument doc;
    JsonArray arr = doc.to<JsonArray>();

    for (uint8_t i = 0; i < bellCount; i++) {
        JsonObject obj = arr.add<JsonObject>();
        obj["id"] = bells[i].id;
        obj["hour"] = bells[i].hour;
        obj["minute"] = bells[i].minute;
        obj["duration"] = bells[i].duration;
        obj["days"] = bells[i].days;
        obj["enabled"] = bells[i].enabled;
        obj["type"] = bells[i].type;
        obj["daysStr"] = getDaysString(bells[i].days);
    }

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
}

void handleCreateBell() {
    addCorsHeaders();

    if (bellCount >= MAX_BELLS) {
        sendError(400, "Numero massimo campanelle raggiunto");
        return;
    }

    if (!server.hasArg("plain")) {
        sendError(400, "Corpo richiesta mancante");
        return;
    }

    JsonDocument doc;
    if (deserializeJson(doc, server.arg("plain"))) {
        sendError(400, "JSON non valido");
        return;
    }

    if (!doc.containsKey("hour") || !doc.containsKey("minute")) {
        sendError(400, "Ora e minuto obbligatori");
        return;
    }

    Bell& bell = bells[bellCount];
    initBell(bell);

    bell.id = findFreeId();
    if (bell.id == 0) {
        sendError(500, "Impossibile generare ID");
        return;
    }

    bell.hour = doc["hour"] | 0;
    bell.minute = doc["minute"] | 0;
    bell.duration = doc["duration"] | DEFAULT_BELL_DURATION;
    bell.days = doc["days"] | DAYS_WEEKDAYS;
    bell.enabled = doc["enabled"] | true;

    if (doc.containsKey("type")) {
        strncpy(bell.type, doc["type"] | "Campanella", MAX_TYPE_LENGTH - 1);
    } else {
        strcpy(bell.type, "Campanella");
    }

    bellCount++;
    saveBells(bells, bellCount);

    JsonDocument respDoc;
    respDoc["success"] = true;
    respDoc["id"] = bell.id;
    String response;
    serializeJson(respDoc, response);
    server.send(201, "application/json", response);
}

void handleUpdateBell() {
    addCorsHeaders();

    String uri = server.uri();
    int lastSlash = uri.lastIndexOf('/');
    uint8_t id = uri.substring(lastSlash + 1).toInt();
    int idx = findBellById(id);

    if (idx < 0) {
        sendError(404, "Campanella non trovata");
        return;
    }

    if (!server.hasArg("plain")) {
        sendError(400, "Corpo richiesta mancante");
        return;
    }

    JsonDocument doc;
    if (deserializeJson(doc, server.arg("plain"))) {
        sendError(400, "JSON non valido");
        return;
    }

    Bell& bell = bells[idx];

    if (doc.containsKey("hour")) bell.hour = doc["hour"];
    if (doc.containsKey("minute")) bell.minute = doc["minute"];
    if (doc.containsKey("duration")) bell.duration = doc["duration"];
    if (doc.containsKey("days")) bell.days = doc["days"];
    if (doc.containsKey("enabled")) bell.enabled = doc["enabled"];
    if (doc.containsKey("type")) {
        strncpy(bell.type, doc["type"] | "", MAX_TYPE_LENGTH - 1);
    }

    saveBells(bells, bellCount);
    sendSuccess("Campanella aggiornata");
}

void handleDeleteBell() {
    addCorsHeaders();

    String uri = server.uri();
    int lastSlash = uri.lastIndexOf('/');
    uint8_t id = uri.substring(lastSlash + 1).toInt();
    int idx = findBellById(id);

    if (idx < 0) {
        sendError(404, "Campanella non trovata");
        return;
    }

    for (int i = idx; i < bellCount - 1; i++) {
        bells[i] = bells[i + 1];
    }
    bellCount--;

    saveBells(bells, bellCount);
    sendSuccess("Campanella eliminata");
}

// === SETTINGS API ===

void handleGetSettings() {
    addCorsHeaders();

    JsonDocument doc;
    doc["institutionName"] = settings.institutionName;
    doc["globalEnabled"] = settings.globalEnabled;

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
}

void handleUpdateSettings() {
    addCorsHeaders();

    if (!server.hasArg("plain")) {
        sendError(400, "Corpo richiesta mancante");
        return;
    }

    JsonDocument doc;
    if (deserializeJson(doc, server.arg("plain"))) {
        sendError(400, "JSON non valido");
        return;
    }

    if (doc.containsKey("institutionName")) {
        strncpy(settings.institutionName, doc["institutionName"] | "", MAX_NAME_LENGTH - 1);
    }
    if (doc.containsKey("globalEnabled")) {
        settings.globalEnabled = doc["globalEnabled"];
    }

    saveSettings(settings);
    sendSuccess("Impostazioni salvate");
}

// === STATUS API ===

void handleGetStatus() {
    addCorsHeaders();

    JsonDocument doc;

    doc["time"] = getTimeStringShort();
    doc["date"] = getDateString();
    doc["timeSet"] = isTimeSet();
    doc["ntpSynced"] = isNtpSynced();

    doc["relayOn"] = systemStatus.relayOn;
    doc["isRinging"] = systemStatus.isRinging;
    doc["ringingBellId"] = systemStatus.ringingBellId;

    doc["globalEnabled"] = settings.globalEnabled;
    doc["institutionName"] = settings.institutionName;

    doc["nextBellTime"] = getNextBellTime();
    doc["nextBellType"] = getNextBellType();

    doc["bellCount"] = bellCount;
    doc["logCount"] = getLogCount();

    doc["wifiState"] = (int)getWiFiState();
    doc["wifiStateName"] = getWiFiStateName();

    doc["version"] = FIRMWARE_VERSION;

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
}

// === RELAY API ===

void handleRelayOn() {
    addCorsHeaders();

    uint8_t duration = DEFAULT_BELL_DURATION;
    if (server.hasArg("plain")) {
        JsonDocument doc;
        if (!deserializeJson(doc, server.arg("plain"))) {
            duration = doc["duration"] | DEFAULT_BELL_DURATION;
        }
    }

    manualRing(duration);
    sendSuccess("Relay acceso");
}

void handleRelayOff() {
    addCorsHeaders();
    stopRinging();
    sendSuccess("Relay spento");
}

// === LOG API ===

void handleGetLog() {
    addCorsHeaders();

    JsonDocument doc;
    JsonArray arr = doc.to<JsonArray>();

    LogEntry* log = getLog();
    uint8_t count = getLogCount();

    for (int i = count - 1; i >= 0; i--) {
        JsonObject obj = arr.add<JsonObject>();
        obj["bellId"] = log[i].bellId;
        obj["hour"] = log[i].hour;
        obj["minute"] = log[i].minute;
        obj["day"] = log[i].day;
        obj["month"] = log[i].month;
        obj["year"] = log[i].year;

        char timeStr[20];
        snprintf(timeStr, sizeof(timeStr), "%02d:%02d %02d/%02d/%04d",
                 log[i].hour, log[i].minute, log[i].day, log[i].month, log[i].year);
        obj["timeStr"] = timeStr;
    }

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
}

void handleClearLog() {
    addCorsHeaders();
    clearLog();
    sendSuccess("Log cancellato");
}

// === WIFI API ===

void handleGetWifiStatus() {
    addCorsHeaders();

    JsonDocument doc;
    doc["state"] = (int)getWiFiState();
    doc["stateName"] = getWiFiStateName();
    doc["ssid"] = getWiFiSSID();
    doc["ip"] = getLocalIP();
    doc["rssi"] = WiFi.RSSI();
    doc["ntpSynced"] = isNtpSynced();
    doc["isAP"] = isInAPMode();

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
}

void handleWifiScan() {
    addCorsHeaders();

    Serial.println("[API] Scansione WiFi in corso...");

    // Esegui scansione (sincrona)
    int n = WiFi.scanNetworks(false, false);

    JsonDocument doc;
    JsonArray arr = doc.to<JsonArray>();

    if (n > 0) {
        for (int i = 0; i < n; i++) {
            JsonObject net = arr.add<JsonObject>();
            net["ssid"] = WiFi.SSID(i);
            net["rssi"] = WiFi.RSSI(i);
            net["secure"] = WiFi.encryptionType(i) != WIFI_AUTH_OPEN;
        }
    }

    // Pulisci risultati scansione
    WiFi.scanDelete();

    Serial.printf("[API] Trovate %d reti\n", n);

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
}

void handleSetWifi() {
    addCorsHeaders();

    if (!server.hasArg("plain")) {
        sendError(400, "Corpo richiesta mancante");
        return;
    }

    JsonDocument doc;
    if (deserializeJson(doc, server.arg("plain"))) {
        sendError(400, "JSON non valido");
        return;
    }

    const char* ssid = doc["ssid"] | "";
    const char* password = doc["password"] | "";

    if (strlen(ssid) == 0) {
        sendError(400, "SSID obbligatorio");
        return;
    }

    // Salva credenziali
    saveWiFiCredentials(ssid, password);

    JsonDocument respDoc;
    respDoc["success"] = true;
    respDoc["message"] = "Credenziali salvate, riavvio in corso...";
    String response;
    serializeJson(respDoc, response);
    server.send(200, "application/json", response);

    // Riavvia dopo un breve delay
    delay(1000);
    restartDevice();
}

// === TIMEZONE API ===

void handleGetTimezone() {
    addCorsHeaders();

    JsonDocument doc;
    doc["gmtOffset"] = getGmtOffset();
    doc["dstOffset"] = getDstOffset();

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
}

void handleSetTimezone() {
    addCorsHeaders();

    if (!server.hasArg("plain")) {
        sendError(400, "Corpo richiesta mancante");
        return;
    }

    JsonDocument doc;
    if (deserializeJson(doc, server.arg("plain"))) {
        sendError(400, "JSON non valido");
        return;
    }

    int32_t gmtOffset = doc["gmtOffset"] | GMT_OFFSET_SEC;
    int32_t dstOffset = doc["dstOffset"] | 0;

    setTimezone(gmtOffset, dstOffset);
    saveTimezone(gmtOffset, dstOffset);

    // Forza risincronizzazione NTP
    if (isWiFiConnected()) {
        syncNTP();
    }

    sendSuccess("Timezone salvato");
}

// === ROUTE SETUP ===

void setupApiRoutes() {
    // CORS preflight
    server.on("/api/bells", HTTP_OPTIONS, handleOptions);
    server.on("/api/settings", HTTP_OPTIONS, handleOptions);
    server.on("/api/status", HTTP_OPTIONS, handleOptions);
    server.on("/api/relay/on", HTTP_OPTIONS, handleOptions);
    server.on("/api/relay/off", HTTP_OPTIONS, handleOptions);
    server.on("/api/log", HTTP_OPTIONS, handleOptions);
    server.on("/api/wifi", HTTP_OPTIONS, handleOptions);
    server.on("/api/wifi/status", HTTP_OPTIONS, handleOptions);
    server.on("/api/wifi/scan", HTTP_OPTIONS, handleOptions);
    server.on("/api/timezone", HTTP_OPTIONS, handleOptions);

    // Bells
    server.on("/api/bells", HTTP_GET, handleGetBells);
    server.on("/api/bells", HTTP_POST, handleCreateBell);

    // Settings
    server.on("/api/settings", HTTP_GET, handleGetSettings);
    server.on("/api/settings", HTTP_PUT, handleUpdateSettings);

    // Status
    server.on("/api/status", HTTP_GET, handleGetStatus);

    // Relay
    server.on("/api/relay/on", HTTP_POST, handleRelayOn);
    server.on("/api/relay/off", HTTP_POST, handleRelayOff);

    // Log
    server.on("/api/log", HTTP_GET, handleGetLog);
    server.on("/api/log", HTTP_DELETE, handleClearLog);

    // WiFi
    server.on("/api/wifi", HTTP_POST, handleSetWifi);
    server.on("/api/wifi/status", HTTP_GET, handleGetWifiStatus);
    server.on("/api/wifi/scan", HTTP_GET, handleWifiScan);

    // Timezone
    server.on("/api/timezone", HTTP_GET, handleGetTimezone);
    server.on("/api/timezone", HTTP_POST, handleSetTimezone);

    Serial.println("[API] Route registrate");
}

// === Handler per /api/bells/{id} ===
bool handleBellsWithId() {
    String uri = server.uri();

    if (!uri.startsWith("/api/bells/")) {
        return false;
    }

    addCorsHeaders();

    if (server.method() == HTTP_OPTIONS) {
        server.send(204);
        return true;
    }

    if (server.method() == HTTP_PUT) {
        handleUpdateBell();
        return true;
    }

    if (server.method() == HTTP_DELETE) {
        handleDeleteBell();
        return true;
    }

    if (server.method() == HTTP_GET) {
        int lastSlash = uri.lastIndexOf('/');
        uint8_t id = uri.substring(lastSlash + 1).toInt();
        int idx = findBellById(id);

        if (idx < 0) {
            sendError(404, "Campanella non trovata");
            return true;
        }

        JsonDocument doc;
        doc["id"] = bells[idx].id;
        doc["hour"] = bells[idx].hour;
        doc["minute"] = bells[idx].minute;
        doc["duration"] = bells[idx].duration;
        doc["days"] = bells[idx].days;
        doc["enabled"] = bells[idx].enabled;
        doc["type"] = bells[idx].type;
        doc["daysStr"] = getDaysString(bells[idx].days);

        String response;
        serializeJson(doc, response);
        server.send(200, "application/json", response);
        return true;
    }

    return false;
}

#endif // API_HANDLERS_H
