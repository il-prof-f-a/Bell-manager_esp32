#ifndef WEB_PAGE_H
#define WEB_PAGE_H

#include <pgmspace.h>

// ============================================
// Pagina Web Bell-Manager v2.0
// Con configurazione WiFi e NTP
// ============================================

const char WEB_PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bell-Manager</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Arial, sans-serif; background: #f0f2f5; }

    .header {
      display: flex; justify-content: space-between; align-items: center;
      background: #0180ff; color: white; padding: 15px 20px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    .header-section { text-align: center; }
    .header-title { font-size: 22px; font-weight: bold; }
    .header-label { font-size: 14px; opacity: 0.8; }
    .header-value { font-size: 18px; font-weight: 600; }

    .status-dot {
      display: inline-block; width: 10px; height: 10px;
      border-radius: 50%; margin-right: 6px;
    }
    .status-connected { background: #4caf50; }
    .status-synced { background: #4caf50; box-shadow: 0 0 6px #4caf50; }
    .status-connecting { background: #ff9800; }
    .status-disconnected { background: #f44336; }
    .status-ap { background: #9c27b0; }

    .container {
      max-width: 1200px; margin: 20px auto; padding: 20px;
      background: white; border-radius: 15px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .btn-bar {
      display: flex; flex-wrap: wrap; gap: 10px;
      justify-content: center; margin-bottom: 20px;
    }
    .btn {
      padding: 12px 20px; font-size: 14px; font-weight: 600;
      border: none; border-radius: 25px; cursor: pointer;
      background: #494949; color: white; transition: 0.3s;
    }
    .btn:hover { background: #000; }
    .btn-primary { background: #0180ff; }
    .btn-primary:hover { background: #0066cc; }
    .btn-danger { background: #f44336; }
    .btn-danger:hover { background: #d32f2f; }

    .modal {
      display: none; position: fixed; top: 0; left: 0;
      width: 100%; height: 100%; background: rgba(0,0,0,0.5);
      z-index: 1000; justify-content: center; align-items: center;
    }
    .modal.active { display: flex; }
    .modal-content {
      background: white; padding: 25px; border-radius: 15px;
      max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto;
    }
    .modal-title { margin: 0 0 20px; text-align: center; }

    .form-group { margin-bottom: 15px; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: 600; }
    .form-group input, .form-group select {
      width: 100%; padding: 10px; border: 1px solid #ddd;
      border-radius: 8px; font-size: 14px;
    }

    .form-row { display: flex; gap: 15px; }
    .form-row .form-group { flex: 1; }

    .switch-container { display: flex; align-items: center; gap: 10px; }
    .switch {
      position: relative; width: 50px; height: 26px;
    }
    .switch input { opacity: 0; width: 0; height: 0; }
    .switch .slider {
      position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
      background: #ccc; border-radius: 26px; transition: 0.3s;
    }
    .switch .slider:before {
      content: ""; position: absolute; height: 20px; width: 20px;
      left: 3px; bottom: 3px; background: white;
      border-radius: 50%; transition: 0.3s;
    }
    .switch input:checked + .slider { background: #0180ff; }
    .switch input:checked + .slider:before { transform: translateX(24px); }

    .days-grid {
      display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px;
    }
    .day-btn {
      padding: 8px; border: 2px solid #ddd; border-radius: 8px;
      background: white; cursor: pointer; font-weight: 600; transition: 0.2s;
    }
    .day-btn.active { border-color: #0180ff; background: #e3f2fd; }

    .table-container { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 12px; text-align: center; border-bottom: 1px solid #eee; }
    th { background: #f5f5f5; font-size: 13px; text-transform: uppercase; }
    tr:hover { background: #f9f9f9; }

    .actions { display: flex; gap: 8px; justify-content: center; }
    .action-btn {
      border: none; background: none; cursor: pointer;
      font-size: 18px; padding: 5px; transition: 0.2s;
    }
    .action-btn:hover { transform: scale(1.2); }
    .action-btn.edit { color: #0180ff; }
    .action-btn.delete { color: #f44336; }

    .info-box {
      background: #e3f2fd; padding: 15px; border-radius: 10px;
      margin-bottom: 15px;
    }
    .info-row { display: flex; justify-content: space-between; margin: 5px 0; }

    .wifi-status {
      padding: 10px 15px; border-radius: 8px; margin-bottom: 15px;
      display: flex; align-items: center; gap: 10px;
    }
    .wifi-status.connected { background: #e8f5e9; color: #2e7d32; }
    .wifi-status.ap-mode { background: #f3e5f5; color: #7b1fa2; }
    .wifi-status.disconnected { background: #ffebee; color: #c62828; }

    .log-list {
      max-height: 200px; overflow-y: auto; background: #f5f5f5;
      padding: 10px; border-radius: 8px; font-size: 13px;
    }
    .log-item { padding: 5px 0; border-bottom: 1px solid #ddd; }

    .footer { text-align: center; padding: 20px; color: #666; font-size: 13px; }
  </style>
</head>
<body>
  <div class="header">
    <div class="header-section">
      <div class="header-label">Ora</div>
      <div class="header-value" id="currentTime">--:--</div>
      <div class="header-label" id="currentDate">--/--/----</div>
    </div>
    <div class="header-section">
      <div class="header-title">Bell-Manager</div>
      <div id="wifiStatusHeader">
        <span class="status-dot status-disconnected"></span>
        <span id="wifiStatusText">Disconnesso</span>
      </div>
    </div>
    <div class="header-section">
      <div class="header-label">Prossima</div>
      <div class="header-value" id="nextBellType">Nessuna</div>
      <div class="header-label" id="nextBellTime">--:--</div>
    </div>
  </div>

  <div class="container">
    <h2 id="institutionName" style="text-align:center;margin-bottom:20px;">Istituzione</h2>

    <div class="btn-bar">
      <button class="btn btn-primary" onclick="openModal('addBellModal')">+ Aggiungi Campanella</button>
      <button class="btn" onclick="openModal('settingsModal')">Impostazioni</button>
      <button class="btn" onclick="openModal('wifiModal')">WiFi</button>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>Ora</th>
            <th>Giorni</th>
            <th>Tipo</th>
            <th>Durata</th>
            <th>Attiva</th>
            <th>Azioni</th>
          </tr>
        </thead>
        <tbody id="bellsTable"></tbody>
      </table>
    </div>

    <div class="footer">Bell-Manager v2.0 - Made with love</div>
  </div>

  <!-- Modal Aggiungi/Modifica Campanella -->
  <div class="modal" id="addBellModal">
    <div class="modal-content">
      <h2 class="modal-title" id="bellModalTitle">Aggiungi Campanella</h2>
      <input type="hidden" id="editBellId">

      <div class="form-row">
        <div class="form-group">
          <label>Ora</label>
          <input type="time" id="bellTime">
        </div>
        <div class="form-group">
          <label>Durata (sec)</label>
          <input type="number" id="bellDuration" min="1" max="60" value="3">
        </div>
      </div>

      <div class="form-group">
        <label>Tipo</label>
        <input type="text" id="bellType" placeholder="Es: Intervallo, Fine lezione">
      </div>

      <div class="form-group">
        <label>Giorni</label>
        <div class="days-grid">
          <button type="button" class="day-btn active" data-day="0">Lun</button>
          <button type="button" class="day-btn active" data-day="1">Mar</button>
          <button type="button" class="day-btn active" data-day="2">Mer</button>
          <button type="button" class="day-btn active" data-day="3">Gio</button>
          <button type="button" class="day-btn active" data-day="4">Ven</button>
          <button type="button" class="day-btn" data-day="5">Sab</button>
          <button type="button" class="day-btn" data-day="6">Dom</button>
        </div>
      </div>

      <div class="btn-bar">
        <button class="btn btn-primary" onclick="saveBell()">Salva</button>
        <button class="btn btn-danger" onclick="closeModal('addBellModal')">Annulla</button>
      </div>
    </div>
  </div>

  <!-- Modal Impostazioni -->
  <div class="modal" id="settingsModal">
    <div class="modal-content">
      <h2 class="modal-title">Impostazioni</h2>

      <div class="form-group">
        <label>Nome Istituzione</label>
        <input type="text" id="settingsName" placeholder="Nome istituzione">
      </div>

      <div class="form-group">
        <label>Campanelle Globali</label>
        <div class="switch-container">
          <span>Disabilitate</span>
          <label class="switch">
            <input type="checkbox" id="settingsGlobal" checked>
            <span class="slider"></span>
          </label>
          <span>Abilitate</span>
        </div>
      </div>

      <div class="form-group">
        <label>Fuso Orario (GMT)</label>
        <select id="settingsTimezone">
          <option value="-43200">GMT-12</option>
          <option value="-39600">GMT-11</option>
          <option value="-36000">GMT-10</option>
          <option value="-32400">GMT-9</option>
          <option value="-28800">GMT-8</option>
          <option value="-25200">GMT-7</option>
          <option value="-21600">GMT-6</option>
          <option value="-18000">GMT-5</option>
          <option value="-14400">GMT-4</option>
          <option value="-10800">GMT-3</option>
          <option value="-7200">GMT-2</option>
          <option value="-3600">GMT-1</option>
          <option value="0">GMT+0</option>
          <option value="3600" selected>GMT+1 (Italia)</option>
          <option value="7200">GMT+2</option>
          <option value="10800">GMT+3</option>
          <option value="14400">GMT+4</option>
          <option value="18000">GMT+5</option>
          <option value="21600">GMT+6</option>
          <option value="25200">GMT+7</option>
          <option value="28800">GMT+8</option>
          <option value="32400">GMT+9</option>
          <option value="36000">GMT+10</option>
          <option value="39600">GMT+11</option>
          <option value="43200">GMT+12</option>
        </select>
      </div>

      <div class="form-group">
        <label>Ora Legale</label>
        <div class="switch-container">
          <span>No</span>
          <label class="switch">
            <input type="checkbox" id="settingsDST" checked>
            <span class="slider"></span>
          </label>
          <span>Si (+1 ora)</span>
        </div>
      </div>

      <div class="form-group">
        <label>Log Campanelle</label>
        <div class="log-list" id="bellLog">Nessun log</div>
      </div>

      <div class="btn-bar">
        <button class="btn btn-primary" onclick="saveSettings()">Salva</button>
        <button class="btn btn-danger" onclick="closeModal('settingsModal')">Chiudi</button>
      </div>
    </div>
  </div>

  <!-- Modal WiFi -->
  <div class="modal" id="wifiModal">
    <div class="modal-content">
      <h2 class="modal-title">Configurazione WiFi</h2>

      <div id="wifiStatusBox" class="wifi-status disconnected">
        <span class="status-dot"></span>
        <span id="wifiStatusDetail">Stato sconosciuto</span>
      </div>

      <div class="info-box">
        <div class="info-row"><span>IP:</span><span id="wifiIP">-</span></div>
        <div class="info-row"><span>SSID:</span><span id="wifiSSID">-</span></div>
        <div class="info-row"><span>NTP Sync:</span><span id="wifiNTP">-</span></div>
      </div>

      <div class="form-group">
        <label>Seleziona Rete WiFi</label>
        <div style="display:flex;gap:10px;">
          <select id="wifiNetworkList" style="flex:1;" onchange="selectNetwork(this.value)">
            <option value="">-- Seleziona rete --</option>
          </select>
          <button class="btn" onclick="scanNetworks()" id="scanBtn">Scansiona</button>
        </div>
        <div id="scanStatus" style="font-size:12px;color:#666;margin-top:5px;"></div>
      </div>

      <div class="form-group">
        <label>SSID (o inserisci manualmente)</label>
        <input type="text" id="newWifiSSID" placeholder="Nome rete WiFi">
      </div>

      <div class="form-group">
        <label>Password</label>
        <div style="display:flex;gap:10px;align-items:center;">
          <input type="password" id="newWifiPass" placeholder="Password WiFi" style="flex:1;">
          <button type="button" class="btn" onclick="togglePassword()" id="togglePassBtn" style="padding:10px 15px;">👁</button>
        </div>
      </div>

      <div class="btn-bar">
        <button class="btn btn-primary" onclick="saveWifi()">Salva e Riavvia</button>
        <button class="btn btn-danger" onclick="closeModal('wifiModal')">Chiudi</button>
      </div>
    </div>
  </div>

  <script>
    let bells = [];
    let settings = {};
    let editingId = null;

    // === API Calls ===
    let pendingRequests = 0;
    const MAX_PENDING = 2;

    async function api(url, options = {}) {
      // Evita accumulo richieste
      if (pendingRequests >= MAX_PENDING && !options.priority) {
        return null;
      }

      pendingRequests++;
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);

        const res = await fetch(url, {
          ...options,
          signal: controller.signal,
          headers: { 'Content-Type': 'application/json', ...options.headers }
        });
        clearTimeout(timeout);
        return await res.json();
      } catch (e) {
        if (e.name !== 'AbortError') {
          console.error('API Error:', e);
        }
        return null;
      } finally {
        pendingRequests--;
      }
    }

    // === Load Data ===
    async function loadBells() {
      const data = await api('/api/bells');
      if (data) {
        bells = data;
        renderBells();
      }
    }

    async function loadSettings() {
      const data = await api('/api/settings');
      if (data) {
        settings = data;
        document.getElementById('institutionName').textContent = data.institutionName || 'Istituzione';
        document.getElementById('settingsName').value = data.institutionName || '';
        document.getElementById('settingsGlobal').checked = data.globalEnabled !== false;
      }
    }

    async function loadStatus() {
      const data = await api('/api/status');
      if (data) {
        document.getElementById('currentTime').textContent = data.time || '--:--';
        document.getElementById('currentDate').textContent = data.date || '--/--/----';
        document.getElementById('nextBellType').textContent = data.nextBellType || 'Nessuna';
        document.getElementById('nextBellTime').textContent = data.nextBellTime || '--:--';
        document.getElementById('institutionName').textContent = data.institutionName || 'Istituzione';
        updateWifiStatus(data);
      }
    }

    async function loadWifiInfo() {
      const data = await api('/api/wifi/status');
      if (data) {
        document.getElementById('wifiIP').textContent = data.ip || '-';
        document.getElementById('wifiSSID').textContent = data.ssid || '-';
        document.getElementById('wifiNTP').textContent = data.ntpSynced ? 'Sincronizzato' : 'Non sincronizzato';
        document.getElementById('newWifiSSID').value = data.ssid || '';

        const box = document.getElementById('wifiStatusBox');
        const detail = document.getElementById('wifiStatusDetail');
        box.className = 'wifi-status';

        if (data.state === 4) {
          box.classList.add('ap-mode');
          detail.textContent = 'Modalita Access Point';
        } else if (data.state === 3) {
          box.classList.add('connected');
          detail.textContent = 'Connesso e Sincronizzato';
        } else if (data.state === 2) {
          box.classList.add('connected');
          detail.textContent = 'Connesso (non sync)';
        } else {
          box.classList.add('disconnected');
          detail.textContent = 'Disconnesso';
        }
      }
    }

    async function loadTimezone() {
      const data = await api('/api/timezone');
      if (data) {
        document.getElementById('settingsTimezone').value = data.gmtOffset || 3600;
        document.getElementById('settingsDST').checked = data.dstOffset > 0;
      }
    }

    async function loadLog() {
      const data = await api('/api/log');
      const logDiv = document.getElementById('bellLog');
      if (data && data.length > 0) {
        logDiv.innerHTML = data.map(e =>
          `<div class="log-item">${e.timeStr} - Campanella ${e.bellId}</div>`
        ).join('');
      } else {
        logDiv.innerHTML = 'Nessun log';
      }
    }

    function updateWifiStatus(data) {
      const header = document.getElementById('wifiStatusHeader');
      const text = document.getElementById('wifiStatusText');
      let dotClass = 'status-disconnected';
      let statusText = 'Disconnesso';

      if (data.wifiState === 4) {
        dotClass = 'status-ap';
        statusText = 'AP Mode';
      } else if (data.wifiState === 3) {
        dotClass = 'status-synced';
        statusText = 'Sincronizzato';
      } else if (data.wifiState === 2) {
        dotClass = 'status-connected';
        statusText = 'Connesso';
      } else if (data.wifiState === 1) {
        dotClass = 'status-connecting';
        statusText = 'Connessione...';
      }

      header.innerHTML = `<span class="status-dot ${dotClass}"></span><span>${statusText}</span>`;
    }

    // === Render ===
    function renderBells() {
      const tbody = document.getElementById('bellsTable');
      tbody.innerHTML = bells.map(b => `
        <tr>
          <td>${String(b.hour).padStart(2,'0')}:${String(b.minute).padStart(2,'0')}</td>
          <td>${b.daysStr || getDaysStr(b.days)}</td>
          <td>${b.type}</td>
          <td>${b.duration}s</td>
          <td>
            <label class="switch">
              <input type="checkbox" ${b.enabled ? 'checked' : ''} onchange="toggleBell(${b.id}, this.checked)">
              <span class="slider"></span>
            </label>
          </td>
          <td class="actions">
            <button class="action-btn edit" onclick="editBell(${b.id})">&#9998;</button>
            <button class="action-btn delete" onclick="deleteBell(${b.id})">&#128465;</button>
          </td>
        </tr>
      `).join('');
    }

    function getDaysStr(days) {
      const names = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];
      return names.filter((_, i) => days & (1 << i)).join(' ') || 'Nessuno';
    }

    // === Modal ===
    function openModal(id) {
      document.getElementById(id).classList.add('active');
      if (id === 'settingsModal') {
        loadLog();
        loadTimezone();
      }
      if (id === 'wifiModal') {
        loadWifiInfo();
        scanNetworks();
      }
      if (id === 'addBellModal' && !editingId) {
        resetBellForm();
      }
    }

    function closeModal(id) {
      document.getElementById(id).classList.remove('active');
      if (id === 'addBellModal') {
        editingId = null;
        resetBellForm();
      }
    }

    function resetBellForm() {
      document.getElementById('bellModalTitle').textContent = 'Aggiungi Campanella';
      document.getElementById('editBellId').value = '';
      document.getElementById('bellTime').value = '';
      document.getElementById('bellDuration').value = '3';
      document.getElementById('bellType').value = '';
      document.querySelectorAll('.day-btn').forEach((btn, i) => {
        btn.classList.toggle('active', i < 5);
      });
    }

    // === Bell CRUD ===
    async function saveBell() {
      const time = document.getElementById('bellTime').value;
      const duration = parseInt(document.getElementById('bellDuration').value) || 3;
      const type = document.getElementById('bellType').value;

      if (!time || !type) {
        alert('Compila tutti i campi!');
        return;
      }

      const [hour, minute] = time.split(':').map(Number);
      let days = 0;
      document.querySelectorAll('.day-btn.active').forEach(btn => {
        days |= (1 << parseInt(btn.dataset.day));
      });

      if (days === 0) {
        alert('Seleziona almeno un giorno!');
        return;
      }

      const bellData = { hour, minute, duration, type, days, enabled: true };

      if (editingId) {
        await api('/api/bells/' + editingId, { method: 'PUT', body: JSON.stringify(bellData) });
      } else {
        await api('/api/bells', { method: 'POST', body: JSON.stringify(bellData) });
      }

      closeModal('addBellModal');
      loadBells();
    }

    function editBell(id) {
      const bell = bells.find(b => b.id === id);
      if (!bell) return;

      editingId = id;
      document.getElementById('bellModalTitle').textContent = 'Modifica Campanella';
      document.getElementById('editBellId').value = id;
      document.getElementById('bellTime').value =
        String(bell.hour).padStart(2,'0') + ':' + String(bell.minute).padStart(2,'0');
      document.getElementById('bellDuration').value = bell.duration;
      document.getElementById('bellType').value = bell.type;

      document.querySelectorAll('.day-btn').forEach(btn => {
        const day = parseInt(btn.dataset.day);
        btn.classList.toggle('active', !!(bell.days & (1 << day)));
      });

      openModal('addBellModal');
    }

    async function deleteBell(id) {
      if (!confirm('Eliminare questa campanella?')) return;
      await api('/api/bells/' + id, { method: 'DELETE' });
      loadBells();
    }

    async function toggleBell(id, enabled) {
      await api('/api/bells/' + id, { method: 'PUT', body: JSON.stringify({ enabled }) });
    }

    // === Settings ===
    async function saveSettings() {
      const name = document.getElementById('settingsName').value;
      const globalEnabled = document.getElementById('settingsGlobal').checked;
      const gmtOffset = parseInt(document.getElementById('settingsTimezone').value);
      const dstOffset = document.getElementById('settingsDST').checked ? 3600 : 0;

      await api('/api/settings', {
        method: 'PUT',
        body: JSON.stringify({ institutionName: name, globalEnabled })
      });

      await api('/api/timezone', {
        method: 'POST',
        body: JSON.stringify({ gmtOffset, dstOffset })
      });

      closeModal('settingsModal');
      loadSettings();
      loadStatus();
    }

    // === WiFi ===
    async function scanNetworks() {
      const btn = document.getElementById('scanBtn');
      const status = document.getElementById('scanStatus');
      const select = document.getElementById('wifiNetworkList');

      btn.disabled = true;
      btn.textContent = '...';
      status.textContent = 'Scansione in corso...';

      const data = await api('/api/wifi/scan');

      btn.disabled = false;
      btn.textContent = 'Scansiona';

      if (data && data.length > 0) {
        select.innerHTML = '<option value="">-- Seleziona rete --</option>';
        data.forEach(net => {
          const signal = net.rssi > -50 ? '●●●' : net.rssi > -70 ? '●●○' : '●○○';
          const lock = net.secure ? '🔒' : '';
          select.innerHTML += `<option value="${net.ssid}">${net.ssid} ${signal} ${lock}</option>`;
        });
        status.textContent = `Trovate ${data.length} reti`;
      } else {
        status.textContent = 'Nessuna rete trovata';
      }
    }

    function selectNetwork(ssid) {
      if (ssid) {
        document.getElementById('newWifiSSID').value = ssid;
      }
    }

    function togglePassword() {
      const input = document.getElementById('newWifiPass');
      const btn = document.getElementById('togglePassBtn');
      if (input.type === 'password') {
        input.type = 'text';
        btn.textContent = '🔒';
      } else {
        input.type = 'password';
        btn.textContent = '👁';
      }
    }

    async function saveWifi() {
      const ssid = document.getElementById('newWifiSSID').value;
      const password = document.getElementById('newWifiPass').value;

      if (!ssid) {
        alert('Inserisci SSID!');
        return;
      }

      const result = await api('/api/wifi', {
        method: 'POST',
        body: JSON.stringify({ ssid, password })
      });

      if (result && result.success) {
        alert('Configurazione salvata! Il dispositivo si riavviera...');
        closeModal('wifiModal');
      }
    }

    // === Day Buttons ===
    document.querySelectorAll('.day-btn').forEach(btn => {
      btn.addEventListener('click', () => btn.classList.toggle('active'));
    });

    // === Init ===
    loadBells();
    loadSettings();
    loadStatus();
    // Polling meno frequente (5 sec) per non sovraccaricare ESP32
    setInterval(loadStatus, 5000);
  </script>
</body>
</html>
)rawliteral";

#endif // WEB_PAGE_H
