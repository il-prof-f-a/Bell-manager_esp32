// ============================================
// Bell-Manager ESP32 v2.0
// Firmware per Sonoff POW Elite 16A (POWR316D)
//
// Configurazione Arduino IDE:
//   Board: ESP32 Dev Module
//   PSRAM: Disabled
//   Flash Size: 4MB (32Mb)
//   Partition Scheme: Default 4MB with spiffs
//
// Funzionalita':
//   - WiFi Station con NTP
//   - Fallback ad AP dopo 5 min disconnessione
//   - LED WiFi: off=disconnesso, blink lento=AP,
//               blink veloce=connesso, fisso=sincronizzato
//   - LED Relay: blink lento=1min prima, blink veloce=10sec prima,
//                fisso=suono in corso
//   - Pulsante: breve=relay, lungo=toggle globale,
//               10sec=modalita' configurazione
// ============================================

#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>

// Header del progetto
#include "config.h"
#include "bell_types.h"
#include "gpio_control.h"
#include "tm1621_display.h"
#include "time_sync.h"
#include "storage.h"
#include "wifi_manager.h"
#include "schedule_engine.h"
#include "api_handlers.h"
#include "web_page.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// ============================================
// Variabili Globali
// ============================================

WebServer server(WEB_SERVER_PORT);

Bell bells[MAX_BELLS];
uint8_t bellCount = 0;

Settings settings;
SystemStatus systemStatus;

unsigned long lastSerialStatus = 0;
unsigned long lastDisplayUpdate = 0;

// ============================================
// Callback cambio stato WiFi
// ============================================

void onWifiStateChanged(WiFiState newState) {
  Serial.printf("[MAIN] WiFi state changed: %s\n", getWiFiStateName());

  switch (newState) {
    case WIFI_STATE_DISCONNECTED:
      // LED spento, ritenta connessione
      setWifiLedMode(0);
      break;

    case WIFI_STATE_CONNECTING:
      // LED blink veloce durante connessione
      setWifiLedMode(3);
      break;

    case WIFI_STATE_CONNECTED:
      // Connesso ma non sincronizzato: blink veloce
      setWifiLedMode(3);
      // Tenta sincronizzazione NTP
      Serial.println("[MAIN] Connesso, avvio sync NTP...");
      if (syncNTP()) {
        setWiFiSynced(true);
      }
      break;

    case WIFI_STATE_SYNCED:
      // Connesso e sincronizzato: LED fisso
      setWifiLedMode(1);
      break;

    case WIFI_STATE_AP_MODE:
      // AP mode: LED blink lento
      setWifiLedMode(2);
      break;
  }
}

// ============================================
// Handler Pagina Web
// ============================================

void handleRoot() {
  server.send_P(200, "text/html", WEB_PAGE);
}

void handleNotFound() {
  if (handleBellsWithId()) {
    return;
  }
  server.send(404, "text/plain", "404 Not Found");
}

// ============================================
// Setup Server Web
// ============================================

void setupWebServer() {
  Serial.println("[WEB] Configurazione server...");

  server.on("/", HTTP_GET, handleRoot);
  setupApiRoutes();
  server.onNotFound(handleNotFound);

  server.begin();
  Serial.printf("[WEB] Server avviato su porta %d\n", WEB_SERVER_PORT);
}

// ============================================
// Carica dati da storage
// ============================================

void loadData() {
  Serial.println("[INIT] Caricamento dati...");

  initStorage();

  // Carica impostazioni
  loadSettings(settings);

  // Carica campanelle
  bellCount = loadBells(bells, MAX_BELLS);
  Serial.printf("[INIT] Caricate %d campanelle\n", bellCount);

  // Carica credenziali WiFi
  char ssid[MAX_SSID_LENGTH];
  char pass[MAX_PASS_LENGTH];
  if (loadWiFiCredentials(ssid, sizeof(ssid), pass, sizeof(pass))) {
    setWiFiCredentials(ssid, pass);
  }

  // Carica timezone
  int32_t gmtOffset, dstOffset;
  loadTimezone(&gmtOffset, &dstOffset);
  setTimezone(gmtOffset, dstOffset);
}

// ============================================
// Gestione Pulsante
// ============================================

void handleButton() {
  uint8_t event = readButton();

  if (event == 1) {
    // Pressione breve: toggle relay manuale
    if (systemStatus.isRinging) {
      stopRinging();
      Serial.println("[BUTTON] Campanella fermata");
    } else {
      manualRing(DEFAULT_BELL_DURATION);
      Serial.println("[BUTTON] Campanella manuale attivata");
    }
  }
  else if (event == 2) {
    // Pressione lunga (3s): toggle abilitazione globale
    settings.globalEnabled = !settings.globalEnabled;
    saveSettings(settings);
    Serial.printf("[BUTTON] Campanelle globali: %s\n",
                  settings.globalEnabled ? "ABILITATE" : "DISABILITATE");

    // Feedback: lampeggia LED relay
    for (int i = 0; i < 3; i++) {
      setRelayLedRaw(true);
      delay(100);
      setRelayLedRaw(false);
      delay(100);
    }
  }
  else if (event == 3) {
    // Pressione config (10s): entra in modalita' AP
    Serial.println("[BUTTON] Richiesta modalita' configurazione");

    // Feedback: lampeggia entrambi i LED
    for (int i = 0; i < 5; i++) {
      setWifiLedRaw(true);
      setRelayLedRaw(true);
      delay(100);
      setWifiLedRaw(false);
      setRelayLedRaw(false);
      delay(100);
    }

    requestAPMode();
  }
}

// ============================================
// Aggiorna stato NTP se connesso
// ============================================

void updateNTPStatus() {
  if (getWiFiState() == WIFI_STATE_CONNECTED) {
    updateNTP();

    // Controlla se NTP si e' sincronizzato
    if (isNtpSynced()) {
      setWiFiSynced(true);
    }
  }
}

// ============================================
// Stampa stato periodico
// ============================================

void printSerialStatus() {
  unsigned long now = millis();

  if (now - lastSerialStatus < 30000) return;
  lastSerialStatus = now;

  Serial.println();
  Serial.println("========== STATO SISTEMA ==========");
  Serial.printf("Ora: %s %s\n", getTimeStringShort().c_str(), getDateString().c_str());
  Serial.printf("NTP Sync: %s\n", isNtpSynced() ? "SI" : "NO");
  Serial.printf("WiFi: %s (IP: %s)\n", getWiFiStateName(), getLocalIP().c_str());
  Serial.printf("Campanelle: %d/%d\n", bellCount, MAX_BELLS);
  Serial.printf("Globale: %s\n", settings.globalEnabled ? "ON" : "OFF");
  Serial.printf("Relay: %s\n", systemStatus.relayOn ? "ON" : "OFF");
  Serial.printf("Prossima: %s\n", getNextBellInfo().c_str());
  Serial.printf("Heap: %d bytes\n", ESP.getFreeHeap());
  Serial.println("====================================");
  Serial.println();
}

// ============================================
// Setup
// ============================================

void setup() {
  
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);
  
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("============================================");
  Serial.println("    Bell-Manager ESP32 v" FIRMWARE_VERSION);
  Serial.println("    Sonoff POW Elite 16A");
  Serial.println("============================================");
  Serial.println();

  // Inizializza GPIO
  Serial.println("[INIT] GPIO...");
  initGPIO();

  // Inizializza Display LCD TM1621
  Serial.println("[INIT] Display...");
  initDisplay();
  displayLoading();  // Mostra "----" durante avvio

  // Inizializza stato sistema
  Serial.println("[INIT] Sistema...");
  initSystemStatus(systemStatus);

  // Inizializza NTP
  Serial.println("[INIT] NTP...");
  initNTP();

  // Carica dati da storage
  loadData();

  // Inizializza WiFi Manager
  Serial.println("[INIT] WiFi Manager...");
  initWiFiManager();

  // Avvia WiFi (AP o Station in base alle credenziali salvate)
  if (hasWiFiCredentials()) {
    Serial.println("[INIT] Avvio WiFi Station...");
    startStationMode();
  } else {
    Serial.println("[INIT] Nessuna credenziale WiFi, avvio AP...");
    startAPMode();
  }

  // Attendi inizializzazione WiFi
  delay(500);

  // Setup Web Server
  Serial.println("[INIT] Setup WebServer...");
  setupWebServer();

  Serial.println();
  Serial.println("[INIT] === SISTEMA PRONTO ===");

  if (isInAPMode()) {
    Serial.printf("[INIT] Connetti a WiFi: %s\n", AP_SSID);
    Serial.printf("[INIT] Password: %s\n", AP_PASSWORD);
    Serial.printf("[INIT] Apri: http://%s\n", getLocalIP().c_str());
  } else {
    Serial.println("[INIT] Connessione a WiFi in corso...");
  }
  Serial.println();
}

// ============================================
// Aggiorna Display LCD
// ============================================

void updateDisplayTime() {
  unsigned long now = millis();

  // Aggiorna ogni secondo
  if (now - lastDisplayUpdate < 1000) return;
  lastDisplayUpdate = now;

  // Se campanella in corso, mostra "bELL"
  if (systemStatus.isRinging) {
    displayBell();
    return;
  }

  // Se NTP sincronizzato, mostra ora
  if (isNtpSynced()) {
    struct tm timeinfo;
    if (getLocalTime(&timeinfo)) {
      displayTime(timeinfo.tm_hour, timeinfo.tm_min);
    }
  } else if (getWiFiState() == WIFI_STATE_AP_MODE) {
    // In AP mode, mostra "Conn" per invitare a configurare
    displayConnecting();
  } else {
    // Non sincronizzato, mostra trattini
    displayLoading();
  }
}

// ============================================
// Loop Principale
// ============================================

void loop() {
  // Gestisci richieste web
  server.handleClient();

  // Gestisci WiFi
  updateWiFi();

  // Gestisci NTP
  updateNTPStatus();

  // Esegui scheduler campanelle
  runScheduler();

  // Gestisci pulsante
  handleButton();

  // Aggiorna LED
  updateLEDs();

  // Aggiorna Display LCD
  updateDisplayTime();

  // Stampa stato periodico
  printSerialStatus();

  // Piccolo delay per stabilita'
  delay(10);
}
