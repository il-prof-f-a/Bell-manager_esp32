#ifndef TM1621_DISPLAY_H
#define TM1621_DISPLAY_H

#include <Arduino.h>
#include "config.h"

// ============================================
// Driver Display LCD TM1621
// Per Sonoff POW Elite 16A (POWR316D)
// Display: 2 righe x 4 cifre + simboli unita'
// ============================================

// Comandi TM1621 (6-bit)
#define TM1621_SYS_EN     0x02  // Abilita oscillatore
#define TM1621_LCD_ON     0x06  // Accende LCD
#define TM1621_LCD_OFF    0x04  // Spegne LCD
#define TM1621_RC_256K    0x30  // Oscillatore interno RC 256kHz
#define TM1621_BIAS_COM   0x52  // Bias 1/3, 4 commons (duty 1/4)

// Mappatura segmenti per cifre 0-9
// Segmenti: 0bGFEDCBA (bit 6-0), bit 7 = punto decimale
static const uint8_t DIGIT_SEGMENTS[] = {
    0b00111111,  // 0: ABCDEF
    0b00000110,  // 1: BC
    0b01011011,  // 2: ABDEG
    0b01001111,  // 3: ABCDG
    0b01100110,  // 4: BCFG
    0b01101101,  // 5: ACDFG
    0b01111101,  // 6: ACDEFG
    0b00000111,  // 7: ABC
    0b01111111,  // 8: ABCDEFG
    0b01101111,  // 9: ABCDFG
};

// Caratteri speciali
#define SEG_BLANK   0x00
#define SEG_MINUS   0b01000000  // G (trattino)
#define SEG_DP      0x80        // Punto decimale

// Buffer display (16 bytes per 32 segmenti x 4 comuni)
static uint8_t displayBuffer[16];

// Stato simboli
static bool showVoltageSymbol = false;
static bool showKwhSymbol = false;

// --- Funzioni bit-bang ---

void tm1621SendBit(bool bit) {
    digitalWrite(PIN_LCD_WR, LOW);
    digitalWrite(PIN_LCD_DATA, bit ? HIGH : LOW);
    delayMicroseconds(5);
    digitalWrite(PIN_LCD_WR, HIGH);
    delayMicroseconds(5);
}

void tm1621SendBits(uint16_t data, uint8_t bits) {
    for (int i = bits - 1; i >= 0; i--) {
        tm1621SendBit((data >> i) & 1);
    }
}

void tm1621SendCommand(uint8_t cmd) {
    digitalWrite(PIN_LCD_CS, LOW);
    delayMicroseconds(5);

    // Header comando: 100 (3 bit) + comando (6 bit) = 9 bit
    tm1621SendBits(0x04, 3);  // 100 = comando
    tm1621SendBits(cmd, 6);

    digitalWrite(PIN_LCD_CS, HIGH);
    delayMicroseconds(5);
}

void tm1621SendData(uint8_t addr, const uint8_t* data, uint8_t length) {
    digitalWrite(PIN_LCD_CS, LOW);
    delayMicroseconds(5);

    // Header scrittura: 101 (3 bit) + indirizzo (6 bit)
    tm1621SendBits(0x05, 3);  // 101 = scrittura dati
    tm1621SendBits(addr & 0x3F, 6);

    // Invia i dati (4 bit per ogni nibble, LSB first per TM1621)
    for (uint8_t i = 0; i < length; i++) {
        // Il TM1621 usa nibble (4 bit) in ordine inverso
        tm1621SendBits(data[i] & 0x0F, 4);
    }

    digitalWrite(PIN_LCD_CS, HIGH);
    delayMicroseconds(5);
}

// --- Inizializzazione ---

void initDisplay() {
    // Configura pin
    pinMode(PIN_LCD_CS, OUTPUT);
    pinMode(PIN_LCD_DATA, OUTPUT);
    pinMode(PIN_LCD_RD, OUTPUT);
    pinMode(PIN_LCD_WR, OUTPUT);

    // Stati iniziali
    digitalWrite(PIN_LCD_CS, HIGH);
    digitalWrite(PIN_LCD_RD, LOW);  // Non usiamo lettura
    digitalWrite(PIN_LCD_WR, HIGH);
    digitalWrite(PIN_LCD_DATA, LOW);

    delay(50);  // Attesa power-up

    // Sequenza inizializzazione TM1621
    tm1621SendCommand(TM1621_SYS_EN);   // Abilita sistema
    tm1621SendCommand(TM1621_RC_256K);  // Clock interno
    tm1621SendCommand(TM1621_BIAS_COM); // Bias e comuni
    tm1621SendCommand(TM1621_LCD_ON);   // Accendi LCD

    // Pulisci buffer
    memset(displayBuffer, 0, sizeof(displayBuffer));

    Serial.println("[DISPLAY] TM1621 inizializzato");
}

// --- Pulizia display ---

void clearDisplay() {
    memset(displayBuffer, 0, sizeof(displayBuffer));
    tm1621SendData(0x00, displayBuffer, 16);
}

// --- Aggiorna display dal buffer ---

void updateDisplay() {
    tm1621SendData(0x00, displayBuffer, 16);
}

// --- Scrivi una cifra in una posizione ---
// row: 0 = riga superiore, 1 = riga inferiore
// pos: 0-3 (da sinistra a destra)
// digit: 0-9, oppure -1 per blank, -2 per trattino
// dp: true per mostrare punto decimale

void setDigit(uint8_t row, uint8_t pos, int8_t digit, bool dp) {
    if (pos > 3) return;

    uint8_t seg = SEG_BLANK;

    if (digit >= 0 && digit <= 9) {
        seg = DIGIT_SEGMENTS[digit];
    } else if (digit == -2) {
        seg = SEG_MINUS;
    }

    if (dp) {
        seg |= SEG_DP;
    }

    // Calcola indice nel buffer
    // Layout tipico TM1621: ogni digit usa 2 nibble consecutivi
    // Riga 0: indirizzi 0-7, Riga 1: indirizzi 8-15
    uint8_t baseAddr = (row == 0) ? 0 : 8;
    uint8_t idx = baseAddr + (pos * 2);

    if (idx < 15) {
        displayBuffer[idx] = seg & 0x0F;
        displayBuffer[idx + 1] = (seg >> 4) & 0x0F;
    }
}

// --- Scrivi un numero intero su una riga ---

void displayNumber(uint8_t row, int value, uint8_t decimals) {
    if (row > 1) return;

    bool negative = (value < 0);
    if (negative) value = -value;

    // Estrai cifre (max 4)
    int8_t digits[4] = {-1, -1, -1, -1};  // -1 = blank
    int dpPos = -1;  // Posizione punto decimale

    if (decimals > 0 && decimals < 4) {
        dpPos = 3 - decimals;
    }

    // Scomponi il numero
    int tempVal = value;
    for (int i = 3; i >= 0; i--) {
        if (tempVal > 0 || i == 3) {
            digits[i] = tempVal % 10;
            tempVal /= 10;
        }
    }

    // Se negativo, metti trattino nella prima posizione disponibile
    if (negative) {
        for (int i = 0; i < 3; i++) {
            if (digits[i] == -1) {
                digits[i] = -2;  // trattino
                break;
            }
        }
    }

    // Scrivi le cifre
    for (int i = 0; i < 4; i++) {
        bool showDp = (i == dpPos);
        setDigit(row, i, digits[i], showDp);
    }
}

// --- Simboli unita' (V/A e kWh/W) ---
// Nel Sonoff POW Elite, i simboli sono accoppiati:
// V+A oppure kWh+W, non indipendenti

void displayVoltageSymbol(bool show) {
    showVoltageSymbol = show;
    // I simboli sono tipicamente negli ultimi indirizzi del buffer
    // Indirizzo esatto dipende dal layout specifico del display
    // Questo e' un esempio - potrebbe richiedere calibrazione
    if (show) {
        displayBuffer[14] |= 0x01;  // Simbolo V (ipotetico)
        displayBuffer[15] |= 0x01;  // Simbolo A (ipotetico)
        displayBuffer[14] &= ~0x02; // Spegni kWh
        displayBuffer[15] &= ~0x02; // Spegni W
    }
}

void displayKwhSymbol(bool show) {
    showKwhSymbol = show;
    if (show) {
        displayBuffer[14] |= 0x02;  // Simbolo kWh (ipotetico)
        displayBuffer[15] |= 0x02;  // Simbolo W (ipotetico)
        displayBuffer[14] &= ~0x01; // Spegni V
        displayBuffer[15] &= ~0x01; // Spegni A
    }
}

// --- Mostra ora sul display ---
// Riga 0: HH:MM (ore e minuti)
// Riga 1: vuota o messaggio

void displayTime(uint8_t hour, uint8_t minute) {
    // Riga superiore: ore
    setDigit(0, 0, hour / 10, false);
    setDigit(0, 1, hour % 10, true);  // Punto come separatore
    setDigit(0, 2, minute / 10, false);
    setDigit(0, 3, minute % 10, false);

    updateDisplay();
}

// --- Mostra messaggio "bell" ---

void displayBell() {
    // b E L L (approssimato con 7 segmenti)
    // b = 0b01111100 (cdefg)
    // E = 0b01111001 (adefg)
    // L = 0b00111000 (def)
    // L = 0b00111000 (def)

    displayBuffer[0] = 0x0C; displayBuffer[1] = 0x07;  // b
    displayBuffer[2] = 0x09; displayBuffer[3] = 0x07;  // E
    displayBuffer[4] = 0x08; displayBuffer[5] = 0x03;  // L
    displayBuffer[6] = 0x08; displayBuffer[7] = 0x03;  // L

    updateDisplay();
}

// --- Mostra "----" (caricamento) ---

void displayLoading() {
    for (int i = 0; i < 4; i++) {
        setDigit(0, i, -2, false);  // Trattini
        setDigit(1, i, -2, false);
    }
    updateDisplay();
}

// --- Mostra "Conn" (connessione) ---

void displayConnecting() {
    // C o n n
    // C = 0b00111001 (adef)
    // o = 0b01011100 (cdeg)
    // n = 0b01010100 (ceg)
    // n = 0b01010100 (ceg)

    displayBuffer[0] = 0x09; displayBuffer[1] = 0x03;  // C
    displayBuffer[2] = 0x0C; displayBuffer[3] = 0x05;  // o
    displayBuffer[4] = 0x04; displayBuffer[5] = 0x05;  // n
    displayBuffer[6] = 0x04; displayBuffer[7] = 0x05;  // n

    updateDisplay();
}

// --- Spegni display ---

void displayOff() {
    tm1621SendCommand(TM1621_LCD_OFF);
}

// --- Accendi display ---

void displayOn() {
    tm1621SendCommand(TM1621_LCD_ON);
}

#endif // TM1621_DISPLAY_H
